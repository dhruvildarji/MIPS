/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xa0883be4 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Final project/ram/ram.srcs/sources_1/imports/Downloads/sram_8.vhd";
extern char *IEEE_P_3620187407;
extern char *IEEE_P_2592010699;
extern char *STD_TEXTIO;
extern char *IEEE_P_3564397177;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
void ieee_p_3564397177_sub_1281154728_91900896(char *, char *, char *, char *, char *, unsigned char , int );
void ieee_p_3564397177_sub_2889341154_91900896(char *, char *, char *, char *, char *);
int ieee_p_3620187407_sub_514432868_3965413181(char *, char *, char *);


static void work_a_3749350711_3953472870_p_0(char *t0)
{
    char t52[8];
    unsigned char t1;
    unsigned char t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    unsigned char t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;
    unsigned char t19;
    unsigned char t20;
    char *t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    char *t27;
    char *t28;
    unsigned char t29;
    unsigned char t30;
    unsigned char t31;
    unsigned char t32;
    char *t33;
    char *t34;
    unsigned char t35;
    unsigned char t36;
    char *t37;
    char *t38;
    char *t39;
    int t40;
    int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    int t46;
    int t47;
    int t48;
    int t49;
    int64 t50;
    int64 t51;

LAB0:    xsi_set_current_line(119, ng0);
    t5 = (t0 + 1312U);
    t6 = xsi_signal_has_event(t5);
    if (t6 == 1)
        goto LAB14;

LAB15:    t4 = (unsigned char)0;

LAB16:    if (t4 == 1)
        goto LAB11;

LAB12:    t3 = (unsigned char)0;

LAB13:    if (t3 == 1)
        goto LAB8;

LAB9:    t7 = (t0 + 1152U);
    t16 = xsi_signal_has_event(t7);
    if (t16 == 1)
        goto LAB20;

LAB21:    t15 = (unsigned char)0;

LAB22:    if (t15 == 1)
        goto LAB17;

LAB18:    t14 = (unsigned char)0;

LAB19:    t2 = t14;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t17 = (t0 + 1312U);
    t26 = xsi_signal_has_event(t17);
    if (t26 == 1)
        goto LAB26;

LAB27:    t25 = (unsigned char)0;

LAB28:    if (t25 == 1)
        goto LAB23;

LAB24:    t24 = (unsigned char)0;

LAB25:    t1 = t24;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    xsi_set_current_line(127, ng0);
    t5 = (t0 + 1192U);
    t7 = *((char **)t5);
    t1 = *((unsigned char *)t7);
    t2 = (t1 == (unsigned char)2);
    if (t2 != 0)
        goto LAB32;

LAB34:    t5 = (t0 + 1152U);
    t1 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t5, 0U, 0U);
    if (t1 != 0)
        goto LAB35;

LAB36:
LAB33:    xsi_set_current_line(133, ng0);
    t5 = (t0 + 1512U);
    t7 = *((char **)t5);
    t1 = *((unsigned char *)t7);
    t2 = (t1 == (unsigned char)2);
    if (t2 != 0)
        goto LAB37;

LAB39:    xsi_set_current_line(136, ng0);
    t5 = xsi_get_transient_memory(8U);
    memset(t5, 0, 8U);
    t7 = t5;
    memset(t7, (unsigned char)4, 8U);
    t8 = (t0 + 7840);
    t11 = (t8 + 56U);
    t17 = *((char **)t11);
    t18 = (t17 + 56U);
    t21 = *((char **)t18);
    memcpy(t21, t5, 8U);
    xsi_driver_first_trans_delta(t8, 0U, 8U, 6000LL);
    t27 = (t0 + 7840);
    xsi_driver_intertial_reject(t27, 6000LL, 6000LL);

LAB38:    xsi_set_current_line(143, ng0);
    t5 = (t0 + 2472U);
    t7 = *((char **)t5);
    t1 = *((unsigned char *)t7);
    t2 = (t1 == (unsigned char)3);
    if (t2 != 0)
        goto LAB40;

LAB42:
LAB41:    xsi_set_current_line(166, ng0);
    t5 = (t0 + 1832U);
    t7 = *((char **)t5);
    t50 = *((int64 *)t7);
    t51 = (2755000 * 1000LL);
    t2 = (t50 > t51);
    if (t2 == 1)
        goto LAB55;

LAB56:    t1 = (unsigned char)0;

LAB57:    if (t1 != 0)
        goto LAB52;

LAB54:
LAB53:    t5 = (t0 + 7632);
    *((int *)t5) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(122, ng0);
    t33 = (t0 + 1672U);
    t37 = *((char **)t33);
    t33 = (t0 + 5448U);
    t38 = *((char **)t33);
    t33 = (t0 + 1032U);
    t39 = *((char **)t33);
    t33 = (t0 + 13508U);
    t40 = ieee_p_3620187407_sub_514432868_3965413181(IEEE_P_3620187407, t39, t33);
    t41 = (t40 - 65535);
    t42 = (t41 * -1);
    xsi_vhdl_check_range_of_index(65535, 0, -1, t40);
    t43 = (8U * t42);
    t44 = (0 + t43);
    t45 = (t38 + t44);
    memcpy(t45, t37, 8U);
    xsi_set_current_line(123, ng0);
    t5 = (t0 + 1032U);
    t7 = *((char **)t5);
    t5 = (t0 + 13508U);
    t40 = ieee_p_3620187407_sub_514432868_3965413181(IEEE_P_3620187407, t7, t5);
    t41 = (t40 - 65535);
    t42 = (t41 * -1);
    t43 = (1 * t42);
    t44 = (0U + t43);
    t8 = (t0 + 7712);
    t11 = (t8 + 56U);
    t17 = *((char **)t11);
    t18 = (t17 + 56U);
    t21 = *((char **)t18);
    *((unsigned char *)t21) = (unsigned char)3;
    xsi_driver_first_trans_delta(t8, t44, 1, 0LL);
    goto LAB3;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t2 = (unsigned char)1;
    goto LAB10;

LAB11:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t12 = *((unsigned char *)t11);
    t13 = (t12 == (unsigned char)2);
    t3 = t13;
    goto LAB13;

LAB14:    t7 = (t0 + 1352U);
    t8 = *((char **)t7);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)3);
    t4 = t10;
    goto LAB16;

LAB17:    t17 = (t0 + 1352U);
    t21 = *((char **)t17);
    t22 = *((unsigned char *)t21);
    t23 = (t22 == (unsigned char)2);
    t14 = t23;
    goto LAB19;

LAB20:    t17 = (t0 + 1192U);
    t18 = *((char **)t17);
    t19 = *((unsigned char *)t18);
    t20 = (t19 == (unsigned char)3);
    t15 = t20;
    goto LAB22;

LAB23:    t27 = (t0 + 1152U);
    t32 = xsi_signal_has_event(t27);
    if (t32 == 1)
        goto LAB29;

LAB30:    t31 = (unsigned char)0;

LAB31:    t24 = t31;
    goto LAB25;

LAB26:    t27 = (t0 + 1352U);
    t28 = *((char **)t27);
    t29 = *((unsigned char *)t28);
    t30 = (t29 == (unsigned char)3);
    t25 = t30;
    goto LAB28;

LAB29:    t33 = (t0 + 1192U);
    t34 = *((char **)t33);
    t35 = *((unsigned char *)t34);
    t36 = (t35 == (unsigned char)3);
    t31 = t36;
    goto LAB31;

LAB32:    xsi_set_current_line(128, ng0);
    t5 = (t0 + 5448U);
    t8 = *((char **)t5);
    t5 = (t0 + 1032U);
    t11 = *((char **)t5);
    t5 = (t0 + 13508U);
    t40 = ieee_p_3620187407_sub_514432868_3965413181(IEEE_P_3620187407, t11, t5);
    t41 = (t40 - 65535);
    t42 = (t41 * -1);
    xsi_vhdl_check_range_of_index(65535, 0, -1, t40);
    t43 = (8U * t42);
    t44 = (0 + t43);
    t17 = (t8 + t44);
    t18 = (t0 + 7776);
    t21 = (t18 + 56U);
    t27 = *((char **)t21);
    t28 = (t27 + 56U);
    t33 = *((char **)t28);
    memcpy(t33, t17, 8U);
    xsi_driver_first_trans_delta(t18, 0U, 8U, 12000LL);
    t34 = (t0 + 7776);
    xsi_driver_intertial_reject(t34, 12000LL, 12000LL);
    goto LAB33;

LAB35:    xsi_set_current_line(130, ng0);
    t7 = xsi_get_transient_memory(8U);
    memset(t7, 0, 8U);
    t8 = t7;
    memset(t8, (unsigned char)4, 8U);
    t11 = (t0 + 7776);
    t17 = (t11 + 56U);
    t18 = *((char **)t17);
    t21 = (t18 + 56U);
    t27 = *((char **)t21);
    memcpy(t27, t7, 8U);
    xsi_driver_first_trans_delta(t11, 0U, 8U, 6000LL);
    t28 = (t0 + 7776);
    xsi_driver_intertial_reject(t28, 6000LL, 6000LL);
    goto LAB33;

LAB37:    xsi_set_current_line(134, ng0);
    t5 = (t0 + 2312U);
    t8 = *((char **)t5);
    t5 = (t0 + 7840);
    t11 = (t5 + 56U);
    t17 = *((char **)t11);
    t18 = (t17 + 56U);
    t21 = *((char **)t18);
    memcpy(t21, t8, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB38;

LAB40:    xsi_set_current_line(144, ng0);
    t5 = (t0 + 7904);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t17 = (t11 + 56U);
    t18 = *((char **)t17);
    *((unsigned char *)t18) = (unsigned char)2;
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(146, ng0);
    t40 = xsi_vhdl_pow(2, 16);
    t41 = (t40 - 1);
    t5 = (t0 + 603820);
    *((int *)t5) = 0;
    t7 = (t0 + 603824);
    *((int *)t7) = t41;
    t46 = 0;
    t47 = t41;

LAB43:    if (t46 <= t47)
        goto LAB44;

LAB46:    xsi_set_current_line(151, ng0);

LAB48:    t5 = (t0 + 6016U);
    t1 = std_textio_endfile(t5);
    t2 = (!(t1));
    if (t2 != 0)
        goto LAB49;

LAB51:    goto LAB41;

LAB44:    xsi_set_current_line(147, ng0);
    t8 = (t0 + 603820);
    t48 = *((int *)t8);
    t49 = (t48 - 65535);
    t42 = (t49 * -1);
    t43 = (1 * t42);
    t44 = (0U + t43);
    t11 = (t0 + 7712);
    t17 = (t11 + 56U);
    t18 = *((char **)t17);
    t21 = (t18 + 56U);
    t27 = *((char **)t21);
    *((unsigned char *)t27) = (unsigned char)2;
    xsi_driver_first_trans_delta(t11, t44, 1, 0LL);
    xsi_set_current_line(148, ng0);
    t5 = xsi_get_transient_memory(8U);
    memset(t5, 0, 8U);
    t7 = t5;
    memset(t7, (unsigned char)2, 8U);
    t8 = (t0 + 5448U);
    t11 = *((char **)t8);
    t8 = (t0 + 603820);
    t40 = *((int *)t8);
    t41 = (t40 - 65535);
    t42 = (t41 * -1);
    xsi_vhdl_check_range_of_index(65535, 0, -1, *((int *)t8));
    t43 = (8U * t42);
    t44 = (0 + t43);
    t17 = (t11 + t44);
    memcpy(t17, t5, 8U);

LAB45:    t5 = (t0 + 603820);
    t46 = *((int *)t5);
    t7 = (t0 + 603824);
    t47 = *((int *)t7);
    if (t46 == t47)
        goto LAB46;

LAB47:    t40 = (t46 + 1);
    t46 = t40;
    t8 = (t0 + 603820);
    *((int *)t8) = t46;
    goto LAB43;

LAB49:    xsi_set_current_line(152, ng0);
    t7 = (t0 + 7120);
    t8 = (t0 + 6016U);
    t11 = (t0 + 6296U);
    std_textio_readline(STD_TEXTIO, t7, t8, t11);
    xsi_set_current_line(153, ng0);
    t5 = (t0 + 7120);
    t7 = (t0 + 6296U);
    t8 = (t0 + 5568U);
    t11 = *((char **)t8);
    t8 = (t11 + 0);
    std_textio_read10(STD_TEXTIO, t5, t7, t8);
    xsi_set_current_line(154, ng0);
    t5 = (t0 + 7120);
    t7 = (t0 + 6296U);
    t8 = (t0 + 5688U);
    t11 = *((char **)t8);
    t8 = (t0 + 13620U);
    ieee_p_3564397177_sub_2889341154_91900896(IEEE_P_3564397177, t5, t7, t11, t8);
    xsi_set_current_line(159, ng0);
    t5 = (t0 + 5688U);
    t7 = *((char **)t5);
    t5 = (t0 + 5448U);
    t8 = *((char **)t5);
    t5 = (t0 + 5568U);
    t11 = *((char **)t5);
    t40 = *((int *)t11);
    t41 = (t40 - 65535);
    t42 = (t41 * -1);
    xsi_vhdl_check_range_of_index(65535, 0, -1, t40);
    t43 = (8U * t42);
    t44 = (0 + t43);
    t5 = (t8 + t44);
    memcpy(t5, t7, 8U);
    xsi_set_current_line(160, ng0);
    t5 = (t0 + 5568U);
    t7 = *((char **)t5);
    t40 = *((int *)t7);
    t41 = (t40 - 65535);
    t42 = (t41 * -1);
    t43 = (1 * t42);
    t44 = (0U + t43);
    t5 = (t0 + 7712);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t17 = (t11 + 56U);
    t18 = *((char **)t17);
    *((unsigned char *)t18) = (unsigned char)3;
    xsi_driver_first_trans_delta(t5, t44, 1, 0LL);
    goto LAB48;

LAB50:;
LAB52:    xsi_set_current_line(167, ng0);
    t5 = (t0 + 7968);
    t11 = (t5 + 56U);
    t17 = *((char **)t11);
    t18 = (t17 + 56U);
    t21 = *((char **)t18);
    *((unsigned char *)t21) = (unsigned char)2;
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(168, ng0);
    t40 = xsi_vhdl_pow(2, 16);
    t41 = (t40 - 1);
    t5 = (t0 + 603828);
    *((int *)t5) = 0;
    t7 = (t0 + 603832);
    *((int *)t7) = t41;
    t46 = 0;
    t47 = t41;

LAB58:    if (t46 <= t47)
        goto LAB59;

LAB61:    xsi_set_current_line(185, ng0);
    t50 = xsi_get_sim_current_time();
    t1 = (t50 > 200000LL);
    t2 = (!(t1));
    if (t2 == 0)
        goto LAB66;

LAB67:    goto LAB53;

LAB55:    t5 = (t0 + 2632U);
    t8 = *((char **)t5);
    t3 = *((unsigned char *)t8);
    t4 = (t3 == (unsigned char)3);
    t1 = t4;
    goto LAB57;

LAB59:    xsi_set_current_line(169, ng0);
    t8 = (t0 + 5448U);
    t11 = *((char **)t8);
    t8 = (t0 + 603828);
    t48 = *((int *)t8);
    t49 = (t48 - 65535);
    t42 = (t49 * -1);
    xsi_vhdl_check_range_of_index(65535, 0, -1, *((int *)t8));
    t43 = (8U * t42);
    t44 = (0 + t43);
    t17 = (t11 + t44);
    t18 = (t0 + 5688U);
    t21 = *((char **)t18);
    t18 = (t21 + 0);
    memcpy(t18, t17, 8U);
    xsi_set_current_line(170, ng0);
    t5 = (t0 + 2152U);
    t7 = *((char **)t5);
    t5 = (t0 + 603828);
    t40 = *((int *)t5);
    t41 = (t40 - 65535);
    t42 = (t41 * -1);
    xsi_vhdl_check_range_of_index(65535, 0, -1, *((int *)t5));
    t43 = (1U * t42);
    t44 = (0 + t43);
    t8 = (t7 + t44);
    t1 = *((unsigned char *)t8);
    t2 = (t1 == (unsigned char)3);
    if (t2 != 0)
        goto LAB62;

LAB64:
LAB63:
LAB60:    t5 = (t0 + 603828);
    t46 = *((int *)t5);
    t7 = (t0 + 603832);
    t47 = *((int *)t7);
    if (t46 == t47)
        goto LAB61;

LAB65:    t40 = (t46 + 1);
    t46 = t40;
    t8 = (t0 + 603828);
    *((int *)t8) = t46;
    goto LAB58;

LAB62:    xsi_set_current_line(171, ng0);
    t11 = (t0 + 603828);
    t17 = (t0 + 5568U);
    t18 = *((char **)t17);
    t17 = (t18 + 0);
    *((int *)t17) = *((int *)t11);
    xsi_set_current_line(172, ng0);
    t5 = (t0 + 7120);
    t7 = (t0 + 6368U);
    t8 = (t0 + 5568U);
    t11 = *((char **)t8);
    t40 = *((int *)t11);
    std_textio_write5(STD_TEXTIO, t5, t7, t40, (unsigned char)0, 0);
    xsi_set_current_line(173, ng0);
    t5 = (t0 + 7120);
    t7 = (t0 + 6120U);
    t8 = (t0 + 6368U);
    std_textio_writeline(STD_TEXTIO, t5, t7, t8);
    xsi_set_current_line(175, ng0);
    t5 = (t0 + 7120);
    t7 = (t0 + 6368U);
    t8 = (t0 + 5688U);
    t11 = *((char **)t8);
    memcpy(t52, t11, 8U);
    t8 = (t0 + 13620U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t5, t7, t52, t8, (unsigned char)0, 0);
    xsi_set_current_line(179, ng0);
    t5 = (t0 + 7120);
    t7 = (t0 + 6120U);
    t8 = (t0 + 6368U);
    std_textio_writeline(STD_TEXTIO, t5, t7, t8);
    goto LAB63;

LAB66:    t5 = (t0 + 603836);
    xsi_report(t5, 18U, 2);
    goto LAB67;

}


void ieee_p_2592010699_sub_3130575329_503743352();

extern void work_a_3749350711_3953472870_init()
{
	static char *pe[] = {(void *)work_a_3749350711_3953472870_p_0};
	xsi_register_didat("work_a_3749350711_3953472870", "isim/sram_64k_8.exe.sim/work/a_3749350711_3953472870.didat");
	xsi_register_executes(pe);
	xsi_register_resolution_function(1, 2, (void *)ieee_p_2592010699_sub_3130575329_503743352, 9);
}
