/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *WORK_P_2781628763;
char *IEEE_P_1242562249;
char *GATE_LIB_P_2781628763;
char *STD_STANDARD;
char *IEEE_P_2592010699;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    work_p_2781628763_init();
    ieee_p_1242562249_init();
    gate_lib_p_2781628763_init();
    work_a_0784047154_1181938964_init();
    gate_lib_a_4213677169_2762913819_init();
    gate_lib_a_3891265539_2762913819_init();
    work_a_0207104428_1181938964_init();
    gate_lib_a_2367803265_2762913819_init();
    work_a_0360004389_1181938964_init();
    gate_lib_a_0378462041_2762913819_init();
    work_a_3996662606_1181938964_init();
    work_a_1635510040_1181938964_init();


    xsi_register_tops("work_a_1635510040_1181938964");

    WORK_P_2781628763 = xsi_get_engine_memory("work_p_2781628763");
    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");
    GATE_LIB_P_2781628763 = xsi_get_engine_memory("gate_lib_p_2781628763");
    STD_STANDARD = xsi_get_engine_memory("std_standard");
    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);

    return xsi_run_simulation(argc, argv);

}
