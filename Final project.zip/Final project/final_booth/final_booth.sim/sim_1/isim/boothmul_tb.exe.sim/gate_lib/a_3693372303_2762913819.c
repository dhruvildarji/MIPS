/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xa0883be4 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Final project/final_booth/final_booth.srcs/sources_1/imports/darji1/Lab1/mux2.vhd";



static void gate_lib_a_3693372303_2762913819_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    xsi_set_current_line(16, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB5;

LAB6:    xsi_set_current_line(21, ng0);
    t1 = (t0 + 3312);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t7 = (t5 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t1);

LAB3:    t1 = (t0 + 3232);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(17, ng0);
    t1 = (t0 + 1032U);
    t5 = *((char **)t1);
    t6 = *((unsigned char *)t5);
    t1 = (t0 + 3312);
    t7 = (t1 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = t6;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB3;

LAB5:    xsi_set_current_line(19, ng0);
    t1 = (t0 + 1192U);
    t5 = *((char **)t1);
    t6 = *((unsigned char *)t5);
    t1 = (t0 + 3312);
    t7 = (t1 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = t6;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB3;

}


extern void gate_lib_a_3693372303_2762913819_init()
{
	static char *pe[] = {(void *)gate_lib_a_3693372303_2762913819_p_0};
	xsi_register_didat("gate_lib_a_3693372303_2762913819", "isim/boothmul_tb.exe.sim/gate_lib/a_3693372303_2762913819.didat");
	xsi_register_executes(pe);
}

extern void gate_lib_a_2147931948_2762913819_init()
{
	static char *pe[] = {(void *)gate_lib_a_3693372303_2762913819_p_0};
	xsi_register_didat("gate_lib_a_2147931948_2762913819", "isim/boothmul_tb.exe.sim/gate_lib/a_2147931948_2762913819.didat");
	xsi_register_executes(pe);
}

extern void gate_lib_a_0171943999_2762913819_init()
{
	static char *pe[] = {(void *)gate_lib_a_3693372303_2762913819_p_0};
	xsi_register_didat("gate_lib_a_0171943999_2762913819", "isim/boothmul_tb.exe.sim/gate_lib/a_0171943999_2762913819.didat");
	xsi_register_executes(pe);
}

extern void gate_lib_a_2750402250_2762913819_init()
{
	static char *pe[] = {(void *)gate_lib_a_3693372303_2762913819_p_0};
	xsi_register_didat("gate_lib_a_2750402250_2762913819", "isim/boothmul_tb.exe.sim/gate_lib/a_2750402250_2762913819.didat");
	xsi_register_executes(pe);
}

extern void gate_lib_a_4219696907_2762913819_init()
{
	static char *pe[] = {(void *)gate_lib_a_3693372303_2762913819_p_0};
	xsi_register_didat("gate_lib_a_4219696907_2762913819", "isim/boothmul_tb.exe.sim/gate_lib/a_4219696907_2762913819.didat");
	xsi_register_executes(pe);
}
