/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xa0883be4 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Final project/final_booth/final_booth.srcs/sources_1/imports/darji1/Lab1/dff.vhd";



static void gate_lib_a_3003662121_2762913819_p_0(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    char *t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    unsigned char t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;

LAB0:    xsi_set_current_line(18, ng0);
    t3 = (t0 + 1352U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 == 1)
        goto LAB8;

LAB9:    t2 = (unsigned char)0;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t3 = (t0 + 3800);
    *((int *)t3) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(20, ng0);
    t10 = (t0 + 1832U);
    t14 = *((char **)t10);
    t15 = *((unsigned char *)t14);
    if (t15 != 0)
        goto LAB11;

LAB13:    xsi_set_current_line(33, ng0);
    t3 = (t0 + 3896);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(34, ng0);
    t3 = (t0 + 3960);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t3);

LAB12:    goto LAB3;

LAB5:    t10 = (t0 + 1192U);
    t11 = *((char **)t10);
    t12 = *((unsigned char *)t11);
    t13 = (t12 == (unsigned char)3);
    t1 = t13;
    goto LAB7;

LAB8:    t3 = (t0 + 1312U);
    t7 = xsi_signal_last_value(t3);
    t8 = *((unsigned char *)t7);
    t9 = (t8 == (unsigned char)2);
    t2 = t9;
    goto LAB10;

LAB11:    xsi_set_current_line(22, ng0);
    t10 = (t0 + 1032U);
    t16 = *((char **)t10);
    t17 = *((unsigned char *)t16);
    t18 = (t17 == (unsigned char)2);
    if (t18 != 0)
        goto LAB14;

LAB16:    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t1 = *((unsigned char *)t4);
    t2 = (t1 == (unsigned char)3);
    if (t2 != 0)
        goto LAB17;

LAB18:    xsi_set_current_line(29, ng0);
    t3 = (t0 + 3896);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(30, ng0);
    t3 = (t0 + 3960);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t3);

LAB15:    goto LAB12;

LAB14:    xsi_set_current_line(23, ng0);
    t10 = (t0 + 3896);
    t19 = (t10 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    *((unsigned char *)t22) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t10);
    xsi_set_current_line(24, ng0);
    t3 = (t0 + 3960);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t3);
    goto LAB15;

LAB17:    xsi_set_current_line(26, ng0);
    t3 = (t0 + 3896);
    t7 = (t3 + 56U);
    t10 = *((char **)t7);
    t11 = (t10 + 56U);
    t14 = *((char **)t11);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(27, ng0);
    t3 = (t0 + 3960);
    t4 = (t3 + 56U);
    t7 = *((char **)t4);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t3);
    goto LAB15;

}

static void a_3003662121_2762913819d_implicit_stable_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 4024);
    xsi_driver_trans_implicit_signal_stable_or_quiet(t1, 2000LL);
    t2 = (t0 + 3816);
    *((int *)t2) = 1;

LAB1:    return;
}


extern void gate_lib_a_3003662121_2762913819_init()
{
	static char *pe[] = {(void *)gate_lib_a_3003662121_2762913819_p_0,(void *)a_3003662121_2762913819d_implicit_stable_0};
	xsi_register_didat("gate_lib_a_3003662121_2762913819", "isim/boothmul_tb.exe.sim/gate_lib/a_3003662121_2762913819.didat");
	xsi_register_executes(pe);
}

extern void gate_lib_a_2494507949_2762913819_init()
{
	static char *pe[] = {(void *)gate_lib_a_3003662121_2762913819_p_0,(void *)a_3003662121_2762913819d_implicit_stable_0};
	xsi_register_didat("gate_lib_a_2494507949_2762913819", "isim/boothmul_tb.exe.sim/gate_lib/a_2494507949_2762913819.didat");
	xsi_register_executes(pe);
}
