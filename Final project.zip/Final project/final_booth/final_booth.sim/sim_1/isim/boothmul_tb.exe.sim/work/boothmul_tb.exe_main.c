/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *STD_STANDARD;
char *GATE_LIB_P_2781628763;
char *IEEE_P_2592010699;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    gate_lib_p_2781628763_init();
    gate_lib_a_3693372303_2762913819_init();
    gate_lib_a_2147931948_2762913819_init();
    gate_lib_a_0171943999_2762913819_init();
    gate_lib_a_2750402250_2762913819_init();
    gate_lib_a_4219696907_2762913819_init();
    gate_lib_a_3003662121_2762913819_init();
    gate_lib_a_2494507949_2762913819_init();
    work_a_3021054972_1181938964_init();
    work_a_1367549779_1181938964_init();
    gate_lib_a_1247273154_2762913819_init();
    gate_lib_a_2346270466_2762913819_init();
    work_a_1853691248_1181938964_init();
    gate_lib_a_2092588860_2762913819_init();
    gate_lib_a_1617806158_2762913819_init();
    work_a_2345003745_1181938964_init();
    gate_lib_a_0180096204_2762913819_init();
    work_a_2464741480_1181938964_init();
    work_a_1410708384_1181938964_init();
    gate_lib_a_1610464134_2762913819_init();
    work_a_1553815316_1181938964_init();
    work_a_1683216120_1181938964_init();
    work_a_0057278119_1181938964_init();
    work_a_1665911382_2372691052_init();


    xsi_register_tops("work_a_1665911382_2372691052");

    STD_STANDARD = xsi_get_engine_memory("std_standard");
    GATE_LIB_P_2781628763 = xsi_get_engine_memory("gate_lib_p_2781628763");
    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);

    return xsi_run_simulation(argc, argv);

}
